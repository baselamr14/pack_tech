# -*- coding: utf-8 -*-
# Part of Softhealer Technologies.

from . import sh_message_wizard
