# -*- coding: utf-8 -*-
{
    'name': "IVS Unique Lot",
    'summary': """One Lot In Components""",
    'description': """One Lot In Components""",
    'author': 'I Value Solutions',
    'website': 'https://www.ivalue-s.com',
    'email': 'info@ivalue-s.com',
    'license': 'OPL-1',
    'category': 'Inventory',
    'version': '16.0.0.0',
    'depends': ['stock','mrp'],

    'data': [
        'views/product.xml',
    ],


}
