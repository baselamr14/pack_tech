from odoo import api, fields, models


class MrpRoutingWorkcenter(models.Model):
    _inherit='mrp.routing.workcenter'
