# -*- coding: utf-8 -*-
{
    'name': "IVS Bom Duration",
    'summary': """Bom Duration""",
    'description': """Bom Duration""",
    'author': 'I Value Solutions',
    'website': 'https://www.ivalue-s.com',
    'email': 'info@ivalue-s.com',
    'license': 'OPL-1',
    'category': 'MAnufacturing',
    'version': '16.0.1',
    'depends': ['stock','mrp'],

    'data': [
        'views/bom.xml',
    ],


}
